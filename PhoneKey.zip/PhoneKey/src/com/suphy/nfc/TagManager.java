package com.suphy.nfc;

import android.app.Activity;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.IntentFilter.MalformedMimeTypeException;
import android.nfc.NfcAdapter;
import android.nfc.Tag;
import android.nfc.tech.MifareUltralight;
import android.util.Log;
import android.widget.Toast;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;


/**
 * @author wanwei.baiww 2013.3.11
 * 
 */
public class TagManager {

    private static Tag mTag = null;
    
    private static byte[] mUID = null;
    
    private static NfcAdapter mNfcAdapter;
    
    public static final String STD_LSAT_KEYS = "std_last.keys";
    
    public static final String STD_KEYS = "std.keys";

    private static final String LOG_TAG = TagManager.class.getSimpleName();
    
    public static final String UUID = "4FB0F3947C8CD1E9118F3BCCA5985A45";
    
    /**
     * 激活成功
     */
    public static int TAG_ACTIVITE_SUCCESS = 0;
    
    /**
     * 标签无连接
     */
    public static int TAG_NOT_CONNECT = 1;
    
    /**
     * 标签写入失败
     */
    public static int TAG_WRITE_FAILED = 2;
    
    /**
     * 认证失败
     */
    public static int TAG_AUTH_FAILED = 3;
    
    /**
     * 认证成功
     */
    public static int TAG_AUTH_SUCCESS = 4;
    
    
    /**
     * 重置成功
     */
    public static int TAG_RESET_SUCCESS = 5;
    
    /**
     * Enables the NFC foreground dispatch system for the given Activity.
     * @param targetActivity The Activity that is in foreground and wants to
     * have NFC Intents.
     * @see #disableNfcForegroundDispatch(Activity)
     */
    public static void enableNfcForegroundDispatch(Activity targetActivity) {
        if (mNfcAdapter != null && mNfcAdapter.isEnabled()) {

            Intent intent = new Intent(targetActivity,targetActivity.getClass()).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
            
            PendingIntent pendingIntent = PendingIntent.getActivity(targetActivity, 0, intent, 0);
            
            IntentFilter ndef = new IntentFilter(NfcAdapter.ACTION_TECH_DISCOVERED);
//            try {
//                ndef.addDataType("*/*");
//            } catch (MalformedMimeTypeException e) {
//                throw new RuntimeException("fail", e);
//            }
            IntentFilter mFilters[] = new IntentFilter[] {
                    ndef,
            };
            
            //String [][]mTechLists = new String[][] { new String[] { NfcA.class.getName(),MifareUltralight.class.getName()} };
            String [][]mTechLists = new String[][] { new String[] { MifareUltralight.class.getName()} };
            mNfcAdapter.enableForegroundDispatch(targetActivity, pendingIntent, mFilters, mTechLists);
        }
    }
    
    /**
     * Disable the NFC foreground dispatch system for the given Activity.
     * @param targetActivity An Activity that is in foreground and has
     * NFC foreground dispatch system enabled.
     * @see #enableNfcForegroundDispatch(Activity)
     */
    public static void disableNfcForegroundDispatch(Activity targetActivity) {
        if (mNfcAdapter != null && mNfcAdapter.isEnabled()) {
            mNfcAdapter.disableForegroundDispatch(targetActivity);
        }
    }
    
    
    /**
     * For Activities which want to treat new Intents as Intents with a new
     * Tag attached. If the given Intent has a Tag extra, the
     * {@link #mTag} and {@link #mUID} will be updated and a Toast
     * message will be shown in the calling Context (Activity).
     * @param intent The Intent which should be checked for a new Tag.
     * @param context The Context in which the Toast will be shown.
     * @see #mTag
     * @see #mUID
     */
    public static void treatAsNewTag(Intent intent, Context context) {
        // Check if Intent has a NFC Tag.
        if (NfcAdapter.ACTION_TECH_DISCOVERED.equals(intent.getAction())) {
            Tag tag = intent.getParcelableExtra(NfcAdapter.EXTRA_TAG);
            mTag = tag;
            mUID = tag.getId();

            // Show Toast message with UID.
            String id = context.getResources().getString(R.string.info_new_tag_found) + " (UID ";
            id += byte2HexString(tag.getId());
            id += ")";
            Toast.makeText(context, id, Toast.LENGTH_LONG).show();
        }
    }
    
    
    /**
     * Convert an array of bytes into a string of hex values.
     * @param bytes Bytes to convert.
     * @return The bytes in hex string format.
     */
    public static String byte2HexString(byte[] bytes) {
        String ret = "";
        for (Byte b : bytes) {
            ret += String.format("%02X", b.intValue() & 0xFF);
        }
        return ret;
    }
    
    /**
     * Convert a string of hex data into a byte array.
     * Original author is: Dave L. (http://stackoverflow.com/a/140861).
     * @param s The hex string to convert
     * @return An array of bytes with the values of the string.
     */
    public static byte[] hexStringToByteArray(String s) {
        int len = s.length();
        byte[] data = new byte[len / 2];
        try {
            for (int i = 0; i < len; i += 2) {
                data[i / 2] = (byte) ((Character.digit(s.charAt(i), 16) << 4)
                                     + Character.digit(s.charAt(i+1), 16));
            }
        } catch (Exception e) {
            Log.d(LOG_TAG, "Argument(s) for hexStringToByteArray(String s)"
                    + "was not a hex string");
        }
        return data;
    }
    
    public static boolean saveKey(byte key[],File file){
        boolean flag = false;
        BufferedOutputStream stream = null; 
        try {   
            if(file.exists())
                file.delete();
            FileOutputStream fstream = new FileOutputStream(file);   
            stream = new BufferedOutputStream(fstream);   
            stream.write(key);   
            flag = true;
        } catch (Exception e) {   
            e.printStackTrace();   
        } finally {   
            if (stream != null) {   
                try {   
                    stream.close();   
                } catch (IOException e1) {   
                    e1.printStackTrace();   
                }   
            }   
        }
        return flag;
    }
    
    public static void deleteKey(String dirName){
        File file = new File(dirName,STD_LSAT_KEYS);
        if(file.exists())
            file.delete();
    }
    
    public static boolean saveKey(byte key[],String dirName){
        boolean flag = false;
        BufferedOutputStream stream = null; 
        File file = null;
        try {   
            file = new File(dirName,STD_KEYS);
            if(file.exists())
                file.renameTo(new File(dirName,STD_LSAT_KEYS));
            
            file = new File(dirName,STD_KEYS);
            FileOutputStream fstream = new FileOutputStream(file);   
            stream = new BufferedOutputStream(fstream);   
            stream.write(key);   
            flag = true;
        } catch (Exception e) {   
            e.printStackTrace();   
        } finally {   
            if (stream != null) {   
                try {   
                    stream.close();   
                } catch (IOException e1) {   
                    e1.printStackTrace();   
                }   
            }   
        }
        return flag;
    }
    
    public static byte[] getKey(File file){
        if(!file.exists())
            return null;
        BufferedInputStream stream = null; 
        byte key[] = new byte[24];
        try {   
            FileInputStream fstream = new FileInputStream(file);   
            stream = new BufferedInputStream(fstream);   
            stream.read(key);
        } catch (Exception e) {   
            e.printStackTrace();  
            return null;
        } finally {   
            if (stream != null) {   
                try {   
                    stream.close();   
                } catch (IOException e1) {   
                    e1.printStackTrace();   
                }   
            }   
        }
        return key;
    }
    
    
    public static Tag getTag() {
        return mTag;
    }

    public static void setTag(Tag mTag) {
        TagManager.mTag = mTag;
    }

    public static byte[] getUID() {
        return mUID;
    }

    public static void setUID(byte[] mUID) {
        TagManager.mUID = mUID;
    }

    public static NfcAdapter getNfcAdapter() {
        return mNfcAdapter;
    }

    public static void setNfcAdapter(NfcAdapter mNfcAdapter) {
        TagManager.mNfcAdapter = mNfcAdapter;
    }
    
}
