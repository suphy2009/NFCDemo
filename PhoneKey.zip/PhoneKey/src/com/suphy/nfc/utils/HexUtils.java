package com.suphy.nfc.utils;

import com.suphy.nfc.TagManager;

public class HexUtils {

    public static byte[] intToByte(int i) {  
        byte[] bt = new byte[4];  
        bt[0] = (byte) (0xff & i);  
        bt[1] = (byte) ((0xff00 & i) >> 8);  
        bt[2] = (byte) ((0xff0000 & i) >> 16);  
        bt[3] = (byte) ((0xff000000 & i) >> 24);  
        return bt;  
    } 
    
    
    public static void main(String[] args) {
        byte[] a = intToByte(0);
        System.err.println("length:");
        
        String uuid = "4FB0F3947C8CD1E9118F3BCCA5985A45";
        byte[] data = TagManager.hexStringToByteArray(uuid);
        
        System.out.println("uuid: " + uuid);
        System.out.println("uuid: " + bytesToHexString(data));
    }
    
    private static final byte[] HEX_CHAR_TABLE = { (byte) '0', (byte) '1',
        (byte) '2', (byte) '3', (byte) '4', (byte) '5', (byte) '6',
        (byte) '7', (byte) '8', (byte) '9', (byte) 'A', (byte) 'B',
        (byte) 'C', (byte) 'D', (byte) 'E', (byte) 'F' };
    
    public static String getHexString(byte[] _raw, int _length) 
    {
        byte[] hex = new byte[2 * _length];
        int index = 0;
        int position = 0;

        for (byte b : _raw) 
        {
            if (position >= _length)
            {
                break;
            }
            position++;
            int temp = b & 0xFF;
            hex[index++] = HEX_CHAR_TABLE[temp >>> 4];
            hex[index++] = HEX_CHAR_TABLE[temp & 0xF];
        }

        return new String(hex);
    }
    
    //字符序列转换为16进制字符串
    public static String bytesToHexString(byte[] src) {
        StringBuilder stringBuilder = new StringBuilder();
        if (src == null || src.length <= 0) {
            return null;
        }
        char[] buffer = new char[2];
        for (int i = 0; i < src.length; i++) {
            buffer[0] = Character.forDigit((src[i] >>> 4) & 0x0F, 16);
            buffer[1] = Character.forDigit(src[i] & 0x0F, 16);
            //System.out.println(buffer);
            stringBuilder.append(buffer);
        }
        return stringBuilder.toString();
    }
    
    public static String getHex(byte[] bytes) {
        StringBuilder sb = new StringBuilder();
        for (int i = bytes.length - 1; i >= 0; --i) {
            int b = bytes[i] & 0xff;
            if (b < 0x10)
                sb.append('0');
            sb.append(Integer.toHexString(b));
            if (i > 0) {
                sb.append(" ");
            }
        }
        return sb.toString();
    }

    public static long getDec(byte[] bytes) {
        long result = 0;
        long factor = 1;
        for (int i = 0; i < bytes.length; ++i) {
            long value = bytes[i] & 0xffl;
            result += value * factor;
            factor *= 256l;
        }
        return result;
    }
}
