package com.suphy.nfc.utils;

import java.security.Key;
import java.security.SecureRandom;
import java.util.Arrays;
import java.util.Random;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESedeKeySpec;
import javax.crypto.spec.IvParameterSpec;
public class DESedeCoder {

    /**
     * 密钥算法
     */
    public static final String KEY_ALGORITHM = "DESede";

    /**
     * 加密/解密算法 / 工作模式 / 填充方式
     * Java 6支持PKCS5PADDING填充方式
     * Bouncy Castle支持PKCS7Padding填充方式
     */
    public static final String CIPHER_ALGORITHM = "DESede/CBC/NoPadding";
    
    /**
     * 转换密钥
     * 
     * @param key
     *            二进制密钥
     * @return Key 密钥
     * @throws Exception
     */
    private static Key toKey(byte[] key) throws Exception {

        // 实例化DES密钥材料
        DESedeKeySpec dks = new DESedeKeySpec(key);

        // 实例化秘密密钥工厂
        SecretKeyFactory keyFactory = SecretKeyFactory.getInstance(KEY_ALGORITHM);

        // 生成秘密密钥
        SecretKey secretKey = keyFactory.generateSecret(dks);
        
        //SecretKey secretKey = new SecretKeySpec(key, KEY_ALGORITHM);

        return secretKey;
    }

    /**
     * 加密
     * 
     * @param data
     *            待加密数据
     * @param key
     *            密钥
     * @return byte[] 加密数据
     * @throws Exception
     */
    public static byte[] encrypt(byte[] data, byte[] key,byte[] ivb) throws Exception {

        // 还原密钥
        Key k = toKey(key);
        
        IvParameterSpec iv = new IvParameterSpec(ivb);
        /* 
         * 实例化
         * 使用PKCS7Padding填充方式
         * Cipher.getInstance(CIPHER_ALGORITHM, "BC");
         */
        Cipher cipher = Cipher.getInstance(CIPHER_ALGORITHM);

        // 初始化，设置为加密模式
        cipher.init(Cipher.ENCRYPT_MODE, k,iv);

        // 执行操作
        return cipher.doFinal(data);
    }


    
    /**
     * 解密
     * 
     * @param data
     *            待解密数据
     * @param key
     *            密钥
     * @return byte[] 解密数据
     * @throws Exception
     */
    public static byte[] decrypt(byte[] data, byte[] key,byte[] ivb) throws Exception {

        // 还原密钥
        Key k = toKey(key);
        IvParameterSpec iv = new IvParameterSpec(ivb);
        /* 
         * 实例化
         * 使用PKCS7Padding填充方式
         * Cipher.getInstance(CIPHER_ALGORITHM, "BC");
         */
        Cipher cipher = Cipher.getInstance(CIPHER_ALGORITHM);

        // 初始化，设置为解密模式
        cipher.init(Cipher.DECRYPT_MODE, k, iv);

        // 执行操作
        return cipher.doFinal(data);
    }
    
    /**
     * 获得标签初始密钥
     * @return
     */
    public static byte[] getKey(){
        //String keyA = "49454D4B41455242";
        //String keyB = "214E4143554F5946";
        
        byte []key1 = new byte[8];
        byte []key2 = new byte[8];
        
        key1[0] = 0x49;
        key1[1] = 0x45;
        key1[2] = 0x4D;
        key1[3] = 0x4B;
        key1[4] = 0x41;
        key1[5] = 0x45;
        key1[6] = 0x52;
        key1[7] = 0x42;
        
        key2[0] = 0x21;
        key2[1] = 0x4E;
        key2[2] = 0x41;
        key2[3] = 0x43;
        key2[4] = 0x55;
        key2[5] = 0x4F;
        key2[6] = 0x59;
        key2[7] = 0x46;
        
        byte[] key = new byte[24];
        System.arraycopy(key1,0,key,0,key1.length);
        System.arraycopy(key2,0,key,key1.length,key2.length);
        System.arraycopy(key1,0,key,key1.length + key2.length,key1.length);
        
        return key;
    }
    
    
    /**
     * 生成密钥 <br>
     * 
     * @return byte[] 二进制密钥
     * @throws Exception
     */
    public static byte[] initKey() throws Exception {

        // 实例化
        KeyGenerator kg = KeyGenerator.getInstance(KEY_ALGORITHM);

        /*
         * DESede 要求密钥长度为 112位或168位
         */
        kg.init(168,new SecureRandom());

        // 生成秘密密钥
        SecretKey secretKey = kg.generateKey();

        // 获得密钥的二进制编码形式
        return secretKey.getEncoded();
    }
    
    
    public static byte[] init3DesKey() throws Exception{
        byte keyBytes[] = initKey();
        byte key[] = Arrays.copyOf(keyBytes, 24);
        for (int j = 0, k = 16; j < 8;) {
            key[k++] = key[j++];
        }
        return key;
    }
    
    
    public static byte[][] getAuthKey(byte initKey[]){
        byte [][]key = new byte[2][8];
        
        byte key1[] = new byte[8];
        byte key2[] = new byte[8];
        
        System.arraycopy(initKey, 0, key1, 0, key1.length);
        System.arraycopy(initKey, key1.length, key2, 0, key2.length);
        
        System.out.println("Before key1: " + HexUtils.bytesToHexString(key1));
        System.out.println("Before key2: " + HexUtils.bytesToHexString(key2));
        
        for(int i = 0,k = key1.length - 1; k >= 0;){
            key[0][i++] = key1[k--];
        }
        
        for(int i = 0,k = key2.length - 1; k >= 0;){
            key[1][i++] = key2[k--];
        }
        
        System.out.println("After key1: " + HexUtils.bytesToHexString(key[0]));
        System.out.println("After key2: " + HexUtils.bytesToHexString(key[1]));
        return key;
    }
    
    public static String getCharAndNum(int length) {   
        String val = "";   
        Random random = new Random();   
        for(int i = 0; i < length; i++)   
        {   
            String charOrNum = random.nextInt(2) % 2 == 0 ? "char" : "num"; // 输出字母还是数字   
                   
            if("char".equalsIgnoreCase(charOrNum))   
            {   
                int choice = random.nextInt(2) % 2 == 0 ? 65 : 97; //取得大写字母还是小写字母   
                val += (char) (choice + random.nextInt(26));   
            }   
            else if("num".equalsIgnoreCase(charOrNum)) // 数字   
            {   
                val += String.valueOf(random.nextInt(10));   
            }   
        }   
        return val;   
    } 
    
    public static void main(String[] args) throws Exception {

        String inputStr = "kyleboon";

        byte[] inputData = inputStr.getBytes();
        System.out.println("文本:\t" + inputStr);
        
        byte key[] = getKey();
        System.err.println("密钥:\t" + HexUtils.bytesToHexString(key));
        
        //加密
        inputData = encrypt(inputData, key,new byte[8]);
        //System.err.println("加密后:\t" + Base64.encodeBase64String(inputData));
        
        //解密
        byte[] outputData = decrypt(inputData, key,new byte[8]);

        String outputStr = new String(outputData);
        System.err.println("解密后:\t" + outputStr);
        
        byte keyBytes[] = init3DesKey();
        
        System.out.println("length: " + keyBytes.length);
        System.out.println(HexUtils.bytesToHexString(keyBytes));
        
        //System.out.println(getCharAndNum(8));
    }
    
    
}