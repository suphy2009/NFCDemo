package com.suphy.nfc;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.nfc.NfcAdapter;
import android.nfc.Tag;

import com.suphy.nfc.utils.HexUtils;

import java.io.IOException;
/**
 * 
 * @author wanwei.baiww 2013.3.11
 *
 */
public class PhoneKeyManager {

    private static volatile PhoneKeyManager instance;
    
    private PhoneKeyManager(){
    }
    
    public static PhoneKeyManager getInstance(){
        if(instance == null){
            synchronized (PhoneKeyManager.class) {
                if(instance == null){
                    instance = new PhoneKeyManager();
                }
            }
        }
        return instance;
    }
    
    public void setNfcAdapter(Context context){
        TagManager.setNfcAdapter(NfcAdapter.getDefaultAdapter(context));
    }
    
    public void setTag(Tag tag){
        TagManager.setTag(tag);
    }
    
    
    public boolean isSupportNFC(){
        return TagManager.getNfcAdapter() == null ? false : true;
    }
    
    /**
     * 
     * @return
     */
    public boolean isNfcEnable(){
        if(TagManager.getNfcAdapter() != null
                && TagManager.getNfcAdapter().isEnabled()){
            return true;
        }
        return false;
    }
    
    /**
     * 判断标签是否已经激活
     * @param context
     * @return
     */
    public boolean isActivited(Context context){
        MCReader reader = new MCReader(context,TagManager.getTag());
        boolean result = reader.isTagActivation();
        reader.close();
        return result;
    }
    
    public void setIntent(Intent intent, Context context){
        TagManager.treatAsNewTag(intent, context);
    }
    
    public void enableNfcForegroundDispatch(Activity targetActivity){
        TagManager.enableNfcForegroundDispatch(targetActivity);
    }
    
    public void disableNfcForegroundDispatch(Activity targetActivity){
        TagManager.disableNfcForegroundDispatch(targetActivity);
    }
    
    
    
    /**
     * 激活、补办、绑定标签
     * 
     * TODO 1.判断cid是否合法
     * TODO 2.判断是否已经激活过
     * TODO 3.写UUID
     * TODO 4.写认证密钥到page44 - page45
     * TODO 5.写认证访问控制域 page42,page43
     * TODO 6.写页锁闭控制page40，使page42,page43为只读
     * @return 
     */
    public int activateTag(Context context){
        
        MCReader reader = new MCReader(context,TagManager.getTag());
        reader.connect();
        if(!reader.isConnected()){
            return TagManager.TAG_NOT_CONNECT;
        }
        boolean isActivate = reader.isTagActivation();
        reader.reconnect(TagManager.getTag());
        if(isActivate){
            int state = reader.auth();
            if(state != TagManager.TAG_AUTH_SUCCESS){
                return state;
            }
        }
        
        byte[] data = TagManager.hexStringToByteArray(TagManager.UUID);
        try {
            reader.writeUUID(data);
            reader.writeAuthKey();
            if(!isActivate){ 
                reader.writeAuthConfig();
                int state = reader.auth();
                if(state == TagManager.TAG_AUTH_SUCCESS){
                    //reader.writeAuthAccess();
                    return TagManager.TAG_ACTIVITE_SUCCESS;
                }else{
                    return TagManager.TAG_AUTH_FAILED;
                }
            }
            return TagManager.TAG_ACTIVITE_SUCCESS;
        } catch (IOException e) {
            e.printStackTrace();
            return TagManager.TAG_WRITE_FAILED;
        } catch (Exception e) {
            e.printStackTrace();
            return TagManager.TAG_WRITE_FAILED;
        }finally{
            reader.close();
        }
    }
    
    /**
     * 擦除芯片数据
     * @param context
     */
    public int resetTag(Context context){
        
        MCReader reader = new MCReader(context,TagManager.getTag());
        reader.connect();
        if(!reader.isConnected()){
            return TagManager.TAG_NOT_CONNECT;
        }
        boolean isActivate = reader.isTagActivation();
        reader.reconnect(TagManager.getTag());
        if(isActivate){
            int state = reader.auth();
            if(state != TagManager.TAG_AUTH_SUCCESS){
                return state;
            }
            
            try{
                reader.writeInitAuthConfig();
                reader.writeInitAuthKey();
                byte d[] = new byte[16];
                reader.writeUUID(d);
            } catch (IOException e) {
                e.printStackTrace();
                return TagManager.TAG_WRITE_FAILED;
            } catch (Exception e) {
                e.printStackTrace();
                return TagManager.TAG_WRITE_FAILED;
            }finally{
                reader.close();
            }
        }
        
        
        return TagManager.TAG_RESET_SUCCESS;
    }
    
    public int authTag(Context context){
        MCReader reader = new MCReader(context,TagManager.getTag());
        reader.connect();
        if(!reader.isConnected()){
            return TagManager.TAG_NOT_CONNECT;
        }
        
        int state = reader.auth();
        if(state != TagManager.TAG_AUTH_SUCCESS){
            return state;
        }
        //TODO 读取uuid
        try {
            byte data[] = reader.readUUID();
            String uuid = HexUtils.bytesToHexString(data);
            if(TagManager.UUID.equalsIgnoreCase(uuid)){
                return TagManager.TAG_AUTH_SUCCESS;
            }
            System.out.println("uuid: " + uuid);
            
        } catch (IOException e) {
            e.printStackTrace();
        }finally{
            reader.close();
        }
        return TagManager.TAG_AUTH_FAILED;
    }
    
}
