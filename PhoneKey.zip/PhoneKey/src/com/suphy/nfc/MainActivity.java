
package com.suphy.nfc;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

import com.suphy.nfc.service.PhoneKeyService;

public class MainActivity extends Activity implements OnClickListener{

    Button openLockBT;
    Button activiteTagBT;
    Button resetTagBT;
    Button readBT;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main_lo);
        
        openLockBT = (Button) findViewById(R.id.open_lock);
        activiteTagBT = (Button) findViewById(R.id.activite_tag);
        resetTagBT = (Button) findViewById(R.id.reset_tag);
        readBT = (Button) findViewById(R.id.read_data);
        
        openLockBT.setOnClickListener(this);
        activiteTagBT.setOnClickListener(this);
        resetTagBT.setOnClickListener(this);
        readBT.setOnClickListener(this);
    }
    

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main_lo, menu);
        return true;
    }

    @Override
    public void onClick(View v) {
        int id = v.getId();
        int state = -1;
        Intent intent = new Intent();
        
        switch (id) {
            case R.id.open_lock:
                state = PhoneKeyService.OPEN_LOCK;
                intent.setClass(this, CommonTagActivity.class);
                intent.putExtra("state", state);
                startActivity(intent);
                break;
            case R.id.activite_tag:
                state = PhoneKeyService.ACTIVITE_TAG;
                intent.setClass(this, CommonTagActivity.class);
                intent.putExtra("state", state);
                startActivity(intent);
                break;
            case R.id.reset_tag:
                state = PhoneKeyService.RESET_TAG;
                intent.setClass(this, CommonTagActivity.class);
                intent.putExtra("state", state);
                startActivity(intent);
                break;
            case R.id.read_data:
                intent.setClass(this, Beam.class);
                //intent.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
                startActivity(intent);
                
                break;
        }
        
        
        
        
    }
    
}
