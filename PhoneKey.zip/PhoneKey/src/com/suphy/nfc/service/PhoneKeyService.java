package com.suphy.nfc.service;

import android.app.Application;
import android.content.Context;
import android.nfc.IPhoneKey;
import android.nfc.IPhoneKeyCallBack;
import android.nfc.Tag;
import android.os.RemoteException;
import com.suphy.nfc.PhoneKeyManager;

public class PhoneKeyService extends IPhoneKey.Stub {

    private final String TAG = "phoneKey";
    private static int state = 0;
    public static final int NO_OPERATE = 0;
    public static final int OPEN_LOCK = 1;
    public static final int ACTIVITE_TAG = 2;
    public static final int RESET_TAG = 3;
    
    private PhoneKeyManager keyManager;
    private Context mContext;
    private IPhoneKeyCallBack mCallBack;
    
    public PhoneKeyService(Application application){
        this.mContext = application;
        this.keyManager = PhoneKeyManager.getInstance();
    }
    
    @Override
    public void registKey(int flag,IPhoneKeyCallBack callBack) throws RemoteException {
        // TODO Auto-generated method stub
        state = flag;
        mCallBack = callBack;
    }

    @Override
    public void unregistKey() throws RemoteException {
        // TODO Auto-generated method stub
        state = NO_OPERATE;
        mCallBack = null;
    }

    @Override
    public boolean isEnable() throws RemoteException {
        // TODO Auto-generated method stub
        if(state == OPEN_LOCK || state == ACTIVITE_TAG || state == RESET_TAG)
            return true;
        return false;
    }


    @Override
    public int activiteTag() throws RemoteException {
        
        return keyManager.activateTag(mContext);
    }


    @Override
    public int resetTag() throws RemoteException {
        // TODO Auto-generated method stub
        return keyManager.resetTag(mContext);
    }

    @Override
    public void handleTag(Tag tag) throws RemoteException {
        // TODO Auto-generated method stub
        keyManager.setTag(tag);
        if(state == OPEN_LOCK){
            mCallBack.onFinish(keyManager.authTag(mContext));
        }else if(state == ACTIVITE_TAG){
            mCallBack.onFinish(keyManager.activateTag(mContext));
        }else if(state == RESET_TAG){
            mCallBack.onFinish(keyManager.resetTag(mContext));
        }
    }

    
}
