package com.suphy.nfc;

import android.app.Application;
import android.os.ServiceManager;
import android.os.UserHandle;

import com.suphy.nfc.service.PhoneKeyService;

public class PhoneKeyApplication extends Application {
    
    public static final String SERVICE_NAME = "phonekey";
    
    public PhoneKeyApplication(){
        
    }

    @Override
    public void onCreate() {
        super.onCreate();
        
        if (UserHandle.myUserId() == 0) {
            PhoneKeyManager.getInstance().setNfcAdapter(this);
            
            PhoneKeyService service = new PhoneKeyService(this);
            ServiceManager.addService(SERVICE_NAME, service);
        }
        
    }
}
