package com.suphy.nfc;

import android.content.Context;
import android.nfc.Tag;
import android.nfc.TagLostException;
import android.nfc.tech.MifareClassic;
import android.nfc.tech.MifareUltralight;
import android.util.Log;
import android.widget.Toast;

import com.suphy.nfc.utils.DESedeCoder;
import com.suphy.nfc.utils.HexUtils;

import java.io.File;
import java.io.IOException;
import java.nio.charset.Charset;
import java.util.Arrays;
/**
 * @author wanwei.baiww 2013.3.11
 * 
 */
public class MCReader {

    private static final String LOG_TAG = MCReader.class.getSimpleName();
    private static String tag = "3DES";
    
    private Tag mTag;
    private MifareUltralight mMFU;
    private Context mContext;
    
    public MCReader(Context context,Tag tag){
        if (tag == null) {
            throw new NullPointerException("Tag argument can't be null");
        }
        mContext = context;
        mTag = tag;
        mMFU = MifareUltralight.get(tag);
    }
    
    public boolean writePage(int page,byte data[]){
        boolean flag = false;
        try {
            this.mMFU.writePage(page, data);
            flag = true;
        } catch (IOException e) {
            e.printStackTrace();
        }
        return flag;
    }
    
    public void writeInitAuthConfig() throws IOException{
        byte[] a = new byte[]{0x30, 0x00, 0x00,0x00};
        mMFU.writePage(42, a);
        
        a = new byte[]{0x00, 0x00, 0x00, 0x00};
        mMFU.writePage(43, a);
    }
    
    /**
     * 使page3之后的页需要读写认证
     * @throws IOException
     */
    public void writeAuthConfig() throws IOException{
        byte[] a = new byte[]{0x03, 0x00, 0x00,0x00};
        mMFU.writePage(42, a);
        
        a = new byte[]{0x00, 0x00, 0x00, 0x00};
        mMFU.writePage(43, a);
    }
    
    /**
     * 使page42,43为只读
     * @throws IOException
     */
    public void writeAuthAccess() throws IOException{
        byte a[] = new byte[]{0x00, 0x60, 0x00, 0x00};
        mMFU.writePage(40, a);
    }
    
    public void writeInitAuthKey(){
        byte initKey[] = DESedeCoder.getKey();
        byte [][]key = DESedeCoder.getAuthKey(initKey);
        
        byte page44[] = Arrays.copyOfRange(key[0], 0, 4);
        byte page45[] = Arrays.copyOfRange(key[0], 4, 8);
        byte page46[] = Arrays.copyOfRange(key[1], 0, 4);
        byte page47[] = Arrays.copyOfRange(key[1], 4, 8);
        
        System.out.println("page44: " + HexUtils.bytesToHexString(page44));
        System.out.println("page45: " + HexUtils.bytesToHexString(page45));
        System.out.println("page46: " + HexUtils.bytesToHexString(page46));
        System.out.println("page47: " + HexUtils.bytesToHexString(page47));
        
        try {
            mMFU.writePage(44, page44);
            mMFU.writePage(45, page45);
            mMFU.writePage(46, page46);
            mMFU.writePage(47, page47);
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        String dirName = mContext.getFilesDir().getAbsolutePath();
        File file = new File(dirName,TagManager.STD_KEYS);
        if(file.exists())
            file.delete();
        
    }
    
    public void writeAuthKey() throws Exception {
        byte initKey[] = new byte[24];
        
        initKey = DESedeCoder.init3DesKey();
        System.out.println("initKey: " + HexUtils.bytesToHexString(initKey));
        
        
        //File file = new File(this.getFilesDir().getAbsolutePath(),TagManager.STD_KEYS);
        String dirName = mContext.getFilesDir().getAbsolutePath();
        if(TagManager.saveKey(initKey,dirName)){
            byte [][]key = DESedeCoder.getAuthKey(initKey);
            
            byte page44[] = Arrays.copyOfRange(key[0], 0, 4);
            byte page45[] = Arrays.copyOfRange(key[0], 4, 8);
            byte page46[] = Arrays.copyOfRange(key[1], 0, 4);
            byte page47[] = Arrays.copyOfRange(key[1], 4, 8);
            
            System.out.println("page44: " + HexUtils.bytesToHexString(page44));
            System.out.println("page45: " + HexUtils.bytesToHexString(page45));
            System.out.println("page46: " + HexUtils.bytesToHexString(page46));
            System.out.println("page47: " + HexUtils.bytesToHexString(page47));
            
            try {
                mMFU.writePage(44, page44);
                mMFU.writePage(45, page45);
                mMFU.writePage(46, page46);
                mMFU.writePage(47, page47);
            } catch (Exception e) {
                e.printStackTrace();
                Toast.makeText(mContext, "写入失败！", Toast.LENGTH_SHORT).show();
                //TODO 
                File file = new File(dirName,TagManager.STD_KEYS);
                if(file.exists())
                    file.delete();
                
                file = new File(dirName,TagManager.STD_LSAT_KEYS);
                if(file.exists())
                    file.renameTo(new File(dirName,TagManager.STD_KEYS));
                
                throw e;
            }
            
            TagManager.deleteKey(dirName);
        }
        
        //byte key[] = TagManager.getKey(file);
        //System.out.println("key: " + HexUtils.bytesToHexString(key));
        
        //boolean result = Arrays.equals(initKey, key);
       
        //Toast.makeText(this, "result: " + result, Toast.LENGTH_SHORT).show();
    }
    
    /**
     * 写uuid到page16,17,18,19
     * @param uuid
     * @throws IOException
     */
    public void writeUUID(byte uuid[]) throws IOException{
        mMFU.writePage(16, Arrays.copyOfRange(uuid, 0, 4));
        mMFU.writePage(17, Arrays.copyOfRange(uuid, 4, 8));
        mMFU.writePage(18, Arrays.copyOfRange(uuid, 8, 12));
        mMFU.writePage(19, Arrays.copyOfRange(uuid, 12, 16));
    }
    
    public byte[] readUUID() throws IOException{
        return this.mMFU.readPages(16);
    }
    
    public boolean isTagActivation(){
        try {
            byte data[] = mMFU.readPages(42);
            if(data[0] == 0x30)
                return false;
        } catch (IOException e) {
            e.printStackTrace();
            return true;
        }
        return false;
    }
    
    /**
     * @return 4:认证成功 3:认证失败  1:标签丢失 
     */
    public int auth() {
        
        int flag = TagManager.TAG_AUTH_FAILED;
        try {
            byte command[] = {0x1A,0x00};
            byte cipher[] = mMFU.transceive(command);
            byte cipherB[] = new byte[8];
            System.arraycopy(cipher, 1, cipherB, 0, cipherB.length);
            
            Log.i(tag,"cipherB: " + HexUtils.bytesToHexString(cipherB));
         
            //byte initKey[] = DESedeCoder.getKey();
            byte initKey[] = TagManager.getKey(new File(mContext.getFilesDir().getAbsoluteFile(),TagManager.STD_KEYS));
            if(initKey == null)
                initKey = DESedeCoder.getKey();
            Log.i(tag,"initKey: " + HexUtils.bytesToHexString(initKey));
            
            byte randB[] =  DESedeCoder.decrypt(cipherB, initKey,new byte[8]);
            Log.i(tag,"randB: " + HexUtils.bytesToHexString(randB));
            
            byte randA[] = getRandA();
            Log.i(tag,"randA: " + HexUtils.bytesToHexString(randA));
            
            byte randA1[] = DESedeCoder.encrypt(randA, initKey, cipherB);
            Log.i(tag,"randA1: " + HexUtils.bytesToHexString(randA1));
            
            randB = transformLeft(randB);
            Log.i(tag,"trans Left randB: " + HexUtils.bytesToHexString(randB));
            
            byte randB2[] = DESedeCoder.encrypt(randB,initKey,randA1);
            Log.i(tag,"randB2: " + HexUtils.bytesToHexString(randB2));
            
            byte data[] = new byte[randA1.length + randB2.length + 1];
            data[0] = (byte) 0xAF;
            System.arraycopy(randA1, 0, data, 1, randA.length);
            System.arraycopy(randB2, 0, data, randA1.length + 1, randB2.length);
            Log.i(tag,"data: " + HexUtils.bytesToHexString(data));
            
            byte cipherA[] = mMFU.transceive(data);
            
            byte randA2[] = new byte[8];
            System.arraycopy(cipherA, 1, randA2, 0, randA2.length);
            
            
            Log.i(tag,"randA2: " + HexUtils.bytesToHexString(randA2));
            
            byte ra[] = DESedeCoder.decrypt(randA2, initKey, randB2);
            Log.i(tag,"ra: " + HexUtils.bytesToHexString(ra));
            
            ra = transformRight(ra);
            Log.i(tag,"trans Right ra: " + HexUtils.bytesToHexString(ra));
            
            flag = Arrays.equals(randA, ra) ? TagManager.TAG_AUTH_SUCCESS : TagManager.TAG_AUTH_FAILED;
        } catch (TagLostException e) {
            e.printStackTrace();
            flag = TagManager.TAG_NOT_CONNECT;
        } catch (IOException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        return flag;
    }
    
    private byte[] getRandA() throws Exception{
        byte key[] = DESedeCoder.initKey();
        return Arrays.copyOf(key, 8);
    }
    
    private static byte[] transformRight(final byte origin[]){
        byte rand[] = Arrays.copyOf(origin, origin.length);
        byte end = rand[rand.length-1];
        for(int k = rand.length - 1; k > 0; --k){
            int j = k - 1;
            rand[k] = rand[j];
        }
        rand[0] = end;
        return rand;
    }
    
    private static byte[] transformLeft(final byte origin[]){
        byte rand[] = Arrays.copyOf(origin, origin.length);
        byte start = rand[0];
        for(int k = 0;k < rand.length - 1; ++k){
            int j = k + 1;
            rand[k] = rand[j];
        }
        rand[rand.length - 1] = start;
        return rand;
    }

    public String readMifareUltralight(){
        StringBuffer buffer = new StringBuffer();
        
        String type = "Unknown";
        switch (mMFU.getType()) {
        case MifareUltralight.TYPE_ULTRALIGHT:
            type = "Ultralight";
            break;
        case MifareUltralight.TYPE_ULTRALIGHT_C:
            type = "Ultralight C";
            break;
        }
        buffer.append("Mifare Ultralight type: ");
        buffer.append(type);
        buffer.append("\n");
        
        /**
         * TODO 读取CID  cid可区分该标签是否是客户发布的合法标签。
         */
        
         //buffer.append("Tag CID (hex): ").append(HexUtils.bytesToHexString(getCid())).append("\n");
        
        
        /**
         * 读取UID
         */
        buffer.append("Tag UID (hex): ").append(HexUtils.bytesToHexString(getUid())).append("\n");
        
        int pageCount = 48;
        buffer.append("共").append(pageCount).append("page\n");
        
        for(int k = 0; k < pageCount; k += 4){
            try {
                byte data[] = mMFU.readPages(k);
                for(int i = 0; i < 4; i++){
                    byte[] p = new byte[4];
                    System.arraycopy(data, i * 4, p, 0, 4);
                    
                    buffer.append("Page ")
                    .append(k + i)
                    .append(": ")
                    .append(HexUtils.bytesToHexString(p))
                    .append("\n");
                    
                   /* for(int a = 0; a < p.length; a++) {
                        if (p[a] < (byte)0x20 || p[a] == (byte)0x7F) {
                            p[a] = (byte)0x2E;
                        }
                    }*/
                    
                    buffer.append("US-ASCII: ")
                    .append(new String(p, Charset.forName("US-ASCII")))
                    .append("\n");
                }
                
            } catch (Exception e) {
                e.printStackTrace();
                for(int i = 0; i < 4; i++){
                    buffer.append("Page ")
                    .append(k + i).append(": ")
                    .append("Read Failed")
                    .append("\n");
                }
                continue;
            }
        }
        
        return buffer.toString();
    }
    
    public String readMifareClassic(){
        StringBuffer buffer = new StringBuffer();
        byte[][] KEYS = {MifareClassic.KEY_DEFAULT,MifareClassic.KEY_MIFARE_APPLICATION_DIRECTORY,MifareClassic.KEY_NFC_FORUM};
        boolean auth = false;
        MifareClassic mfc = MifareClassic.get(mTag);
        try {
            //Enable I/O operations to the tag from this TagTechnology object.
            mfc.connect();
            
            int type = mfc.getType();//获取TAG的类型
            int sectorCount = mfc.getSectorCount();//获取TAG中包含的扇区数
            String typeS = "";
            switch (type) {
            case MifareClassic.TYPE_CLASSIC:
                typeS = "TYPE_CLASSIC";
                break;
            case MifareClassic.TYPE_PLUS:
                typeS = "TYPE_PLUS";
                break;
            case MifareClassic.TYPE_PRO:
                typeS = "TYPE_PRO";
                break;
            case MifareClassic.TYPE_UNKNOWN:
                typeS = "TYPE_UNKNOWN";
                break;
            }
            buffer.append("卡片类型：").append(typeS).append("\n");
            buffer.append("共").append(sectorCount).append("个扇区\n");
            buffer.append("共").append(mfc.getBlockCount()).append("个块\n");
            buffer.append("存储空间: ").append(mfc.getSize()).append("B\n");
          
            for (int j = 0; j < sectorCount; j++) {
                for(int k = 0;k < KEYS.length;k++){
                    auth = mfc.authenticateSectorWithKeyA(j,KEYS[k]);
                    if(auth)
                        break;
                }
                int bCount;
                int bIndex;
                if (auth) {
                    buffer.append("Sector ").append(j).append(":验证成功\n");
                    bCount = mfc.getBlockCountInSector(j);
                    bIndex = mfc.sectorToBlock(j);
                    
                    byte[] selector = new byte[48];
                    for (int i = 0; i < bCount; i++) {
                        byte[] data = mfc.readBlock(bIndex);
                        buffer.append("Block ")
                        .append(bIndex).append(": ")
                        .append(HexUtils.bytesToHexString(data))
                        .append("\n");
                       
                        if(i != bCount - 1){
                            /* for(int a = 0; a < data.length; a++) {
                                if (data[a] < (byte)0x20 || data[a] == (byte)0x7F) {
                                    data[a] = (byte)0x2E;
                                }
                            }*/
                            System.arraycopy(data, 0, selector, i * 16, data.length);
                            
                            buffer.append("ASCII: ")
                            .append(new String(data, Charset.forName("US-ASCII")))
                            .append("\n");
                        }
                            
                        bIndex++;
                    }
                    buffer.append("Content: ")
                    .append(new String(selector, Charset.forName("US-ASCII")))
                    .append("\n");
                    
                    buffer.append("------------------------------------\n");
                } else {
                    buffer.append("Sector ").append(j).append(":验证失败\n");
                }
            }
            
        } catch (Exception e) {
            e.printStackTrace();
        }finally{
            try {
                mfc.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        
        return buffer.toString();
    }
    
    public byte[] getUid(){
        byte[] uid = new byte[7];
        try {
            byte data[] = this.mMFU.readPages(0);
            System.arraycopy(data, 0, uid, 0, 3);
            System.arraycopy(data, 4, uid, 3, 4);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return uid;
    }
    
    public byte[] getCid(){
        byte cid[] = new byte[16];
        try {
            byte[] comm = new byte[2];
            comm[0] = 0x30;
            comm[1] = (byte) 0xff;
            cid = this.mMFU.transceive(comm);
        } catch (Exception e1) {
            e1.printStackTrace();
        }
        return  cid;
    }
    
    public boolean isSupportCard(){
        boolean isMifare = false;
        for (String tech : mTag.getTechList()) {
            if (tech.equals(MifareUltralight.class.getName())) {
                isMifare = true;
                break;
            }
        }
        return isMifare;
    }
    
    public boolean isConnected() {
        return mMFU.isConnected();
    }
    
    public void reconnect(Tag tag){
        close();
        mTag = tag;
        mMFU = MifareUltralight.get(tag);
        connect();
    }
    
    public void connect() {
        try {
            //mMFU.setTimeout(6000);
            mMFU.connect();
        } catch (IOException e) {
            Log.d(LOG_TAG, "Error while connecting to tag.");
        }
    }
    
    public void close() {
        try {
            if(mMFU != null) mMFU.close();
        }
        catch (IOException e) {
            Log.d(LOG_TAG, "Error on closing tag.");
        }
    }
    
}
