package com.suphy.nfc;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.nfc.NfcAdapter;
import android.nfc.Tag;
import android.nfc.tech.MifareClassic;
import android.nfc.tech.MifareUltralight;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;
import android.widget.Toast;
import com.suphy.nfc.utils.HexUtils;
import java.io.IOException;

public class Beam extends Activity {
    
    private TextView promt;
    private AlertDialog mEnableNfc;
    private Intent mOldIntent = null;
    
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        promt = (TextView) findViewById(R.id.promt);
        
        TagManager.setNfcAdapter(NfcAdapter.getDefaultAdapter(this));
//        if (TagManager.getNfcAdapter() == null) {
//            new AlertDialog.Builder(this)
//            .setTitle(R.string.dialog_no_nfc_title)
//            .setMessage(R.string.dialog_no_nfc)
//            .setPositiveButton(R.string.button_exit_app,
//                    new DialogInterface.OnClickListener() {
//                public void onClick(DialogInterface dialog, int which) {
//                    finish();
//                }
//             })
//             .setOnCancelListener(new DialogInterface.OnCancelListener() {
//                public void onCancel(DialogInterface dialog) {
//                    finish();
//                }
//             })
//             .show();
//            
//            return;
//        }
        
        
        mEnableNfc = new AlertDialog.Builder(this)
        .setTitle(R.string.dialog_nfc_not_enabled_title)
        .setMessage(R.string.dialog_nfc_not_enabled)
        .setPositiveButton(R.string.button_nfc,
                new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                // Goto NFC Settings.
                startActivity(new Intent(android.provider.Settings.ACTION_NFC_SETTINGS));
                // Enable read/write tag options.
            }
         })
         .setNegativeButton(R.string.button_exit_app,
                 new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                // Exit the App.
                finish();
            }
         }).create();
    }

    @Override
    protected void onResume() {
        super.onResume();
        checkNfc();
        processIntent(getIntent());
    }
    
    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        TagManager.treatAsNewTag(intent, this);
        processIntent(intent);
    }
    
    @Override
    public void onPause() {
        super.onPause();
        TagManager.disableNfcForegroundDispatch(this);
    }
    
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        menu.add(0, 1, 0, "Clear Log");
        menu.add(0, 2, 0, "Write Test");
        menu.add(0, 3, 0, "Write Access Bit");
        menu.add(0, 4, 0, "Write Auth Access");
        menu.add(0, 5, 0, "Write key");
        return super.onCreateOptionsMenu(menu);
    }
    
    
    @Override
    public boolean onMenuItemSelected(int featureId, MenuItem item) {
        int itemId = item.getItemId();
        switch (itemId) {
            case 1:
                promt.setText("");
                break;
            case 2:
                write();
                break;
            case 3:
                writeControlBit(3);
                break;
            case 4:
                writeControlBit(4);
                break;
            case 5:
                writeControlBit(5);
                break;
            default:
                break;
        }
        
        return super.onMenuItemSelected(featureId, item);
    }
    
    private void checkNfc() {
        // Check if the NFC hardware is enabled.
        if (TagManager.getNfcAdapter() != null
                && !TagManager.getNfcAdapter().isEnabled()) {
            // NFC is disabled. Show dialog.
            mEnableNfc.show();
            // Disable read/write tag options.
            return;
        } else {
            // NFC is enabled. Hide dialog and enable NFC
            // foreground dispatch.
            if (mOldIntent != getIntent()) {
                TagManager.treatAsNewTag(getIntent(), this);
                mOldIntent = getIntent();
            }
            TagManager.enableNfcForegroundDispatch(this);
            mEnableNfc.hide();
        }
    }
    
    private void write(){
        MCReader reader = new MCReader(this,TagManager.getTag());
        reader.connect();
        if(!reader.isConnected()){
            Toast.makeText(this, "Tag is not connected", Toast.LENGTH_SHORT).show();
            return;
        }
        int state = reader.auth();
        if(state == TagManager.TAG_NOT_CONNECT){
            Toast.makeText(getApplicationContext(), "tag was lost!!", Toast.LENGTH_SHORT).show();
            this.promt.setText("tag was lost!!");
            reader.close();
            return;
        }else if(state == TagManager.TAG_AUTH_FAILED){
            Toast.makeText(getApplicationContext(), "auth failure!!", Toast.LENGTH_SHORT).show();
            reader.close();
            return;
        }else if(state == TagManager.TAG_AUTH_SUCCESS){
            Toast.makeText(getApplicationContext(), "auth OK!!", Toast.LENGTH_SHORT).show();
        }
        
        boolean flag = reader.writePage(10, "bww".getBytes());
        if(flag){
            Toast.makeText(getApplicationContext(), "write success!", Toast.LENGTH_SHORT).show();
        }else{
            Toast.makeText(getApplicationContext(), "write failed!", Toast.LENGTH_SHORT).show();
        }
            
        reader.close();
    }
    
    /*
     * TODO 1.判断cid是否合法
     * TODO 2.判断是否已经激活过
     * TODO 3.写UUID
     * TODO 4.写认证密钥到page44 - page45
     * TODO 5.写认证访问控制域 page42,page43
     * TODO 6.写页锁闭控制page40，使page42,page43为只读
     */
    public void activationTag(){
        MCReader reader = new MCReader(this,TagManager.getTag());
        reader.connect();
        if(!reader.isConnected()){
            Toast.makeText(this, "Tag is not connected", Toast.LENGTH_SHORT).show();
            return;
        }
        
        String uuid = "4FB0F3947C8CD1E9118F3BCCA5985A45";
        byte[] data = TagManager.hexStringToByteArray(uuid);
        try {
            reader.writeUUID(data);
            reader.writeAuthKey();
            reader.writeAuthConfig();
            
            int state = reader.auth();
            if(state == TagManager.TAG_AUTH_SUCCESS){
                reader.writeAuthAccess();
            }
            Toast.makeText(this, "Tag activation success", Toast.LENGTH_SHORT).show();
        } catch (IOException e) {
            e.printStackTrace();
            return;
        } catch (Exception e) {
            e.printStackTrace();
            return;
        }
    }
    
    
    private void writeControlBit(int flag){
        MCReader reader = new MCReader(this,TagManager.getTag());
        reader.connect();
        if(!reader.isConnected()){
            Toast.makeText(this, "Tag is not connected", Toast.LENGTH_SHORT).show();
            return;
        }
        int state = reader.auth();
        if(state == TagManager.TAG_NOT_CONNECT){
            Toast.makeText(getApplicationContext(), "tag was lost!!", Toast.LENGTH_SHORT).show();
            this.promt.setText("tag was lost!!");
            reader.close();
            return;
        }else if(state == TagManager.TAG_AUTH_FAILED){
            Toast.makeText(getApplicationContext(), "auth failure!!", Toast.LENGTH_SHORT).show();
            return;
        }else if(state == TagManager.TAG_AUTH_SUCCESS){
            Toast.makeText(getApplicationContext(), "auth OK!!", Toast.LENGTH_SHORT).show();
        }
        
        try {
            if(flag == 4){    //修改从page3以后需要读写认证访问
               reader.writeAuthConfig();
            }else if(flag == 5){   //修改page44 - page47认证密钥
               reader.writeAuthKey();
            }
            
            Toast.makeText(getApplicationContext(), "write success!", Toast.LENGTH_SHORT).show();
        } catch (IOException e) {
            e.printStackTrace();
            Toast.makeText(getApplicationContext(), "write failed!", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(getApplicationContext(), "write failed!", Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * Parses the NDEF Message from the intent and prints to the TextView
     */
    private void processIntent(Intent intent) {
        StringBuffer buffer = new StringBuffer();
        String action = intent.getAction();
        buffer.append("Intent Action: \n").append(action).append("\n");
        
        if (NfcAdapter.ACTION_TECH_DISCOVERED.equals(action)) {
            MCReader reader = new MCReader(this,TagManager.getTag());
            
            Tag tag = intent.getParcelableExtra(NfcAdapter.EXTRA_TAG);
            
            buffer.append("Tag ID (hex): ").append(HexUtils.bytesToHexString(TagManager.getUID())).append("\n");
            buffer.append("Tag ID (dec): ").append(HexUtils.getDec(TagManager.getUID())).append("\n");
            for (String tech : tag.getTechList()) {
                buffer.append(tech).append("\n");
            }
            
            for (String tech : tag.getTechList()) {
                if (tech.equals(MifareClassic.class.getName())) { //MifareClassic
                    String content = reader.readMifareClassic();
                    buffer.append(content);
                }
                
                if (tech.equals(MifareUltralight.class.getName())) { //MifareUltralight
                    reader.connect();
                    if (!reader.isConnected()) {
                        return;
                    }
                    boolean result = reader.isTagActivation();
                    //boolean result = true;
                    if(result){
                        reader.reconnect(TagManager.getTag());
                        
                        int flag = reader.auth();
                        if(flag == TagManager.TAG_NOT_CONNECT){
                            Toast.makeText(getApplicationContext(), "tag was lost!!", Toast.LENGTH_SHORT).show();
                            this.promt.setText("tag was lost!!");
                            reader.close();
                            return;
                        }else if(flag == TagManager.TAG_AUTH_FAILED){
                            Toast.makeText(getApplicationContext(), "auth failure!!", Toast.LENGTH_SHORT).show();
                            reader.close();
                            return;
                        }else if(flag == TagManager.TAG_AUTH_SUCCESS){
                            Toast.makeText(getApplicationContext(), "auth OK!!", Toast.LENGTH_SHORT).show();
                        }
                    }
                    String content = reader.readMifareUltralight();
                    buffer.append(content);
                    reader.close();
                }
            }
            promt.setText(buffer.toString());
        }
        
    }

}
