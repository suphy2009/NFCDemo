
package com.suphy.nfc;

import android.app.Activity;
import android.content.Intent;
import android.nfc.IPhoneKey;
import android.nfc.IPhoneKeyCallBack;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.os.RemoteException;
import android.os.ServiceManager;
import android.view.Menu;
import android.widget.TextView;
import android.widget.Toast;

import com.suphy.nfc.service.PhoneKeyService;

public class CommonTagActivity extends Activity {

    private IPhoneKey phoneKeyService;
    private IPhoneKeyCallBack callback;
    private int state;
    private  TextView contentTV;
    Handler mHandler = new Handler(){
        
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case 4:
                    Toast.makeText(CommonTagActivity.this, "Success", Toast.LENGTH_SHORT).show();
                    if (state == PhoneKeyService.OPEN_LOCK) {
                        Intent intent = new Intent("android.intent.action.MUSIC_PLAYER");
                        startActivity(intent);
                    }
                    break;
                case 0:
                    Toast.makeText(CommonTagActivity.this, "Activite Success", Toast.LENGTH_SHORT).show();
                    break;
                case 5:
                    Toast.makeText(CommonTagActivity.this, "Reset Success", Toast.LENGTH_SHORT).show();
                    break;
                default:
                    contentTV.setText("result code: " + msg.what);
                    break;
            }
        };
    };
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_common_tag);
        contentTV = (TextView) findViewById(R.id.content);
        state = getIntent().getIntExtra("state", -1);
        if(state == PhoneKeyService.OPEN_LOCK){
            contentTV.setText("Open Lock...");
        }else if(state == PhoneKeyService.ACTIVITE_TAG){
            contentTV.setText("activite tag...");
        }else if(state == PhoneKeyService.RESET_TAG){
            contentTV.setText("reset tag...");
        }
        
        
        phoneKeyService = getServiceInterface();
        
        IPhoneKeyCallBack.Stub stub = new IPhoneKeyCallBack.Stub(){


            @Override
            public void onFinish(int state) throws RemoteException {
                // TODO Auto-generated method stub
                mHandler.sendEmptyMessage(state);
            }
            
        };
        callback = IPhoneKeyCallBack.Stub.asInterface(stub);
    }
    
    @Override
    protected void onResume() {
        // TODO Auto-generated method stub
        super.onResume();
        try {
            phoneKeyService.registKey(state, callback);
        } catch (RemoteException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }
    
    @Override
    protected void onPause() {
        // TODO Auto-generated method stub
        super.onPause();
        try {
            phoneKeyService.unregistKey();
        } catch (RemoteException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.common_tag, menu);
        return true;
    }

    private static IPhoneKey getServiceInterface(){
        IBinder binder = ServiceManager.getService(PhoneKeyApplication.SERVICE_NAME);
        if(binder == null)
            return null;
        
        return IPhoneKey.Stub.asInterface(binder);
    }
}
